</main>
<footer>
    <div class="container">
        <p>&copy; <?= date('Y') ?> DriveNow Car Rental. Built with PHP & MySQL.</p>
    </div>
</footer>
<script src="assets/js/script.js"></script>
</body>
</html>
