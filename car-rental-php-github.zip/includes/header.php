<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'DriveNow Car Rental') ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<nav class="navbar">
    <div class="container nav-inner">
        <a class="logo" href="index.php">Drive<span>Now</span></a>
        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="cars.php">Cars</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="user/bookings.php">My Bookings</a>
                <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
                    <a href="admin/dashboard.php">Admin</a>
                <?php endif; ?>
                <a class="btn btn-small" href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a class="btn btn-small" href="register.php">Register</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<main>
