# Car Rental Management System

A simple PHP + MySQL car rental project suitable for a college/school project and GitHub.

## Features

- User registration and login
- Browse available cars
- Search/filter cars
- Book a car with pickup and return dates
- Automatic rental price calculation
- User booking history
- Admin dashboard
- Admin car management
- Admin booking management
- MySQL database
- Responsive interface

## Requirements

- PHP 8.0+
- MySQL 5.7+ / MariaDB
- Apache (XAMPP, WAMP, Laragon, etc.)

## Installation

1. Copy the `car-rental-php` folder into your web server directory.
2. Start Apache and MySQL.
3. Open phpMyAdmin.
4. Create a database named `car_rental`.
5. Import `database/car_rental.sql`.
6. Edit `config/database.php` if your MySQL username/password is different.
7. Open:

   `http://localhost/car-rental-php/`

## Demo accounts

Admin:
- Email: admin@carrental.com
- Password: admin123

You can also register a normal user from the website.

## GitHub

Do not upload real production passwords or private database credentials. This project uses local development credentials by default.
