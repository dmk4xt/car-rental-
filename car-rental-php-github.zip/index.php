<?php
require_once 'config/database.php';
require_once 'includes/auth.php';
$pageTitle = 'DriveNow - Car Rental';
$stmt = $pdo->query("SELECT * FROM cars WHERE status='available' ORDER BY id DESC LIMIT 6");
$cars = $stmt->fetchAll();
include 'includes/header.php';
?>
<section class="hero">
<div class="container">
    <h1>Rent the right car for your next journey.</h1>
    <p>Simple, affordable and reliable car rentals. Choose your car, select your dates and get on the road.</p>
    <a class="btn" href="cars.php">Browse Cars</a>
</div>
</section>
<section class="section">
<div class="container">
    <div class="section-title"><h2>Featured Cars</h2><p>Choose from our available vehicles.</p></div>
    <div class="grid">
    <?php foreach($cars as $car): ?>
        <div class="card">
            <div class="car-image">🚗</div>
            <div class="card-body">
                <h3><?= htmlspecialchars($car['brand'].' '.$car['model']) ?></h3>
                <p><?= htmlspecialchars($car['year']) ?> · <?= htmlspecialchars($car['fuel_type']) ?> · <?= htmlspecialchars($car['transmission']) ?></p>
                <div class="price">$<?= number_format($car['price_per_day'],2) ?> / day</div>
                <a class="btn" href="car.php?id=<?= $car['id'] ?>">View & Rent</a>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
</div>
</section>
<section class="section">
<div class="container">
    <div class="features">
        <div class="feature"><h3>🚘 Quality Cars</h3><p>Clean and dependable vehicles for your trip.</p></div>
        <div class="feature"><h3>💳 Simple Pricing</h3><p>Clear daily rates with no confusing calculations.</p></div>
        <div class="feature"><h3>📅 Easy Booking</h3><p>Book your car online in just a few steps.</p></div>
    </div>
</div>
</section>
<?php include 'includes/footer.php'; ?>
