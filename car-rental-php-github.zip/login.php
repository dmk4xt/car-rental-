<?php
require_once 'config/database.php';
require_once 'includes/auth.php';
if (isLoggedIn()) { header('Location: index.php'); exit; }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $email=trim($_POST['email']??''); $password=$_POST['password']??'';
    $stmt=$pdo->prepare("SELECT * FROM users WHERE email=?"); $stmt->execute([$email]); $user=$stmt->fetch();
    if($user && password_verify($password,$user['password'])){
        $_SESSION['user_id']=$user['id']; $_SESSION['name']=$user['name']; $_SESSION['role']=$user['role'];
        header('Location: '.($user['role']==='admin'?'admin/dashboard.php':'index.php')); exit;
    }
    $error='Invalid email or password.';
}
$pageTitle='Login'; include 'includes/header.php';
?>
<div class="form-box"><h2>Login</h2>
<?php if(isset($_GET['registered'])): ?><div class="alert success">Registration successful. You can now log in.</div><?php endif; ?>
<?php if($error): ?><div class="alert"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post">
<div class="form-group"><label>Email</label><input type="email" name="email" required></div>
<div class="form-group"><label>Password</label><input type="password" name="password" required></div>
<button class="btn">Login</button>
</form><br><p>Don't have an account? <a href="register.php">Register</a></p>
</div>
<?php include 'includes/footer.php'; ?>
