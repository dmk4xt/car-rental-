<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
requireLogin();
$carId=(int)($_GET['car_id']??0);
$stmt=$pdo->prepare("SELECT * FROM cars WHERE id=? AND status='available'");
$stmt->execute([$carId]); $car=$stmt->fetch();
if(!$car) die('Car is unavailable or does not exist.');
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $pickup=$_POST['pickup_date']??''; $return=$_POST['return_date']??'';
    if(!$pickup || !$return || $return <= $pickup) $error='Return date must be after pickup date.';
    else {
        $conf=$pdo->prepare("SELECT id FROM bookings WHERE car_id=? AND status IN ('pending','confirmed') AND pickup_date < ? AND return_date > ?");
        $conf->execute([$carId,$return,$pickup]);
        if($conf->fetch()) $error='This car is already booked for those dates.';
        else {
            $days=(new DateTime($pickup))->diff(new DateTime($return))->days;
            $total=$days*$car['price_per_day'];
            $ins=$pdo->prepare("INSERT INTO bookings(user_id,car_id,pickup_date,return_date,total_price,status) VALUES(?,?,?,?,?,'pending')");
            $ins->execute([$_SESSION['user_id'],$carId,$pickup,$return,$total]);
            header('Location: bookings.php?success=1'); exit;
        }
    }
}
$pageTitle='Book Car'; include '../includes/header.php';
?>
<section class="section"><div class="container"><div class="form-box">
<h2>Book <?= htmlspecialchars($car['brand'].' '.$car['model']) ?></h2>
<p class="price">$<?= number_format($car['price_per_day'],2) ?> / day</p>
<?php if($error): ?><div class="alert"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post">
<div class="form-group"><label>Pickup Date</label><input id="pickup_date" type="date" name="pickup_date" min="<?= date('Y-m-d') ?>" required></div>
<div class="form-group"><label>Return Date</label><input id="return_date" type="date" name="return_date" min="<?= date('Y-m-d',strtotime('+1 day')) ?>" required></div>
<input type="hidden" id="daily_price" value="<?= $car['price_per_day'] ?>">
<p id="price-preview" style="font-weight:bold;margin:15px 0"></p>
<button class="btn">Confirm Booking</button>
</form></div></div></section>
<?php include '../includes/footer.php'; ?>
