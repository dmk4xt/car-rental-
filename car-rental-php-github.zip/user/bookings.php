<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
requireLogin();
$stmt=$pdo->prepare("SELECT b.*,c.brand,c.model FROM bookings b JOIN cars c ON c.id=b.car_id WHERE b.user_id=? ORDER BY b.created_at DESC");
$stmt->execute([$_SESSION['user_id']]); $bookings=$stmt->fetchAll();
$pageTitle='My Bookings'; include '../includes/header.php';
?>
<section class="section"><div class="container"><h1>My Bookings</h1><br>
<?php if(isset($_GET['success'])): ?><div class="alert success">Booking submitted successfully.</div><?php endif; ?>
<div class="table-wrap"><table><tr><th>Car</th><th>Pickup</th><th>Return</th><th>Total</th><th>Status</th></tr>
<?php foreach($bookings as $b): ?><tr>
<td><?= htmlspecialchars($b['brand'].' '.$b['model']) ?></td><td><?= htmlspecialchars($b['pickup_date']) ?></td><td><?= htmlspecialchars($b['return_date']) ?></td>
<td>$<?= number_format($b['total_price'],2) ?></td><td><?= htmlspecialchars(ucfirst($b['status'])) ?></td></tr>
<?php endforeach; ?>
</table></div>
<?php if(!$bookings): ?><div class="empty">You have no bookings yet.</div><?php endif; ?>
</div></section>
<?php include '../includes/footer.php'; ?>
