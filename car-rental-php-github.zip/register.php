<?php
require_once 'config/database.php';
require_once 'includes/auth.php';
if (isLoggedIn()) { header('Location: index.php'); exit; }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name=trim($_POST['name']??''); $email=trim($_POST['email']??''); $password=$_POST['password']??'';
    if ($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($password)<6) {
        $error='Enter a valid name/email and a password of at least 6 characters.';
    } else {
        $check=$pdo->prepare("SELECT id FROM users WHERE email=?"); $check->execute([$email]);
        if ($check->fetch()) $error='An account with this email already exists.';
        else {
            $hash=password_hash($password,PASSWORD_DEFAULT);
            $stmt=$pdo->prepare("INSERT INTO users(name,email,password,role) VALUES(?,?,?,'user')");
            $stmt->execute([$name,$email,$hash]);
            header('Location: login.php?registered=1'); exit;
        }
    }
}
$pageTitle='Register'; include 'includes/header.php';
?>
<div class="form-box"><h2>Create Account</h2>
<?php if($error): ?><div class="alert"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post">
<div class="form-group"><label>Name</label><input name="name" required></div>
<div class="form-group"><label>Email</label><input type="email" name="email" required></div>
<div class="form-group"><label>Password</label><input type="password" name="password" minlength="6" required></div>
<button class="btn">Register</button>
</form></div>
<?php include 'includes/footer.php'; ?>
