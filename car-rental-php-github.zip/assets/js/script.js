document.addEventListener('DOMContentLoaded', () => {
    const pickup = document.querySelector('#pickup_date');
    const returnDate = document.querySelector('#return_date');
    const priceBox = document.querySelector('#price-preview');
    const dailyPrice = document.querySelector('#daily_price');

    function updatePrice() {
        if (!pickup || !returnDate || !priceBox || !dailyPrice) return;
        const start = new Date(pickup.value);
        const end = new Date(returnDate.value);
        const price = Number(dailyPrice.value);
        if (start && end && end > start && price) {
            const days = Math.ceil((end - start) / 86400000);
            priceBox.textContent = `Estimated total: $${(days * price).toFixed(2)} (${days} day${days > 1 ? 's' : ''})`;
        } else {
            priceBox.textContent = '';
        }
    }
    pickup?.addEventListener('change', updatePrice);
    returnDate?.addEventListener('change', updatePrice);
});
