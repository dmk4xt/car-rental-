<?php
require_once 'config/database.php';
require_once 'includes/auth.php';
$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM cars WHERE id=?");
$stmt->execute([$id]); $car = $stmt->fetch();
if (!$car) { http_response_code(404); die("Car not found."); }
$pageTitle = $car['brand'].' '.$car['model'];
include 'includes/header.php';
?>
<section class="section"><div class="container">
<div class="card" style="max-width:800px;margin:auto"><div class="car-image" style="height:260px;font-size:100px">🚗</div>
<div class="card-body">
<h1><?= htmlspecialchars($car['brand'].' '.$car['model']) ?></h1>
<p><?= htmlspecialchars($car['description']) ?></p>
<p><strong>Year:</strong> <?= $car['year'] ?> | <strong>Fuel:</strong> <?= htmlspecialchars($car['fuel_type']) ?> | <strong>Transmission:</strong> <?= htmlspecialchars($car['transmission']) ?></p>
<div class="price">$<?= number_format($car['price_per_day'],2) ?> / day</div>
<?php if ($car['status'] === 'available'): ?>
<a class="btn" href="<?= isLoggedIn() ? 'user/book.php?car_id='.$car['id'] : 'login.php' ?>">Rent This Car</a>
<?php else: ?><p>Currently unavailable.</p><?php endif; ?>
</div></div></div></section>
<?php include 'includes/footer.php'; ?>
