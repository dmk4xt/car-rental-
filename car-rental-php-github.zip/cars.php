<?php
require_once 'config/database.php';
require_once 'includes/auth.php';
$pageTitle = 'Available Cars';
$q = trim($_GET['q'] ?? '');
$sql = "SELECT * FROM cars WHERE status='available'";
$params = [];
if ($q !== '') {
    $sql .= " AND (brand LIKE ? OR model LIKE ? OR fuel_type LIKE ? OR transmission LIKE ?)";
    $like = "%$q%";
    $params = [$like,$like,$like,$like];
}
$sql .= " ORDER BY id DESC";
$stmt = $pdo->prepare($sql); $stmt->execute($params); $cars = $stmt->fetchAll();
include 'includes/header.php';
?>
<section class="section"><div class="container">
<h1>Available Cars</h1><br>
<form class="search" method="get">
<input name="q" value="<?= htmlspecialchars($q) ?>" placeholder="Search by brand, model, fuel or transmission">
<button class="btn" type="submit">Search</button>
</form>
<div class="grid">
<?php foreach($cars as $car): ?>
<div class="card"><div class="car-image">🚙</div><div class="card-body">
<h3><?= htmlspecialchars($car['brand'].' '.$car['model']) ?></h3>
<p><?= $car['year'] ?> · <?= htmlspecialchars($car['fuel_type']) ?> · <?= htmlspecialchars($car['transmission']) ?></p>
<div class="price">$<?= number_format($car['price_per_day'],2) ?> / day</div>
<a class="btn" href="car.php?id=<?= $car['id'] ?>">View & Rent</a>
</div></div>
<?php endforeach; ?>
</div>
<?php if(!$cars): ?><div class="empty">No cars found.</div><?php endif; ?>
</div></section>
<?php include 'includes/footer.php'; ?>
