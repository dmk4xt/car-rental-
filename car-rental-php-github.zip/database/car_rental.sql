CREATE DATABASE IF NOT EXISTS car_rental CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE car_rental;

DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS cars;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user','admin') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE cars (
    id INT AUTO_INCREMENT PRIMARY KEY,
    brand VARCHAR(80) NOT NULL,
    model VARCHAR(80) NOT NULL,
    year INT NOT NULL,
    fuel_type VARCHAR(30) NOT NULL,
    transmission VARCHAR(30) NOT NULL,
    price_per_day DECIMAL(10,2) NOT NULL,
    description TEXT,
    status ENUM('available','unavailable') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    car_id INT NOT NULL,
    pickup_date DATE NOT NULL,
    return_date DATE NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    status ENUM('pending','confirmed','completed','cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
);

-- Demo admin account. Password: admin123
INSERT INTO users(name,email,password,role) VALUES
('Administrator','admin@carrental.com','$2y$10$6M9u9kR8H8Hq7dKxVv7M5u5d4Xq4xw5u8oY9p0WQJm8J5uH8wG4K2','admin');

INSERT INTO cars(brand,model,year,fuel_type,transmission,price_per_day,description,status) VALUES
('Toyota','Corolla',2022,'Petrol','Automatic',45.00,'Comfortable and reliable sedan for city and highway trips.','available'),
('Honda','Civic',2023,'Petrol','Automatic',55.00,'Modern sedan with a comfortable interior and smooth drive.','available'),
('Hyundai','Creta',2022,'Petrol','Automatic',60.00,'Spacious SUV suitable for family trips and longer journeys.','available'),
('Suzuki','Swift',2021,'Petrol','Manual',35.00,'Compact and economical car for everyday travel.','available'),
('Tesla','Model 3',2023,'Electric','Automatic',85.00,'Electric sedan with modern technology and excellent performance.','available'),
('Ford','Ranger',2022,'Diesel','Manual',75.00,'Practical pickup for travel, work and adventure.','available');
